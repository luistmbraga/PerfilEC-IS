<template>
  <v-footer dark color="grey lighten-3">
    <v-spacer></v-spacer>
    <div><strong class="black--text">@ORCID Tracker</strong></div>
  </v-footer>
</template>

<script></script>
